﻿param(
    [switch]$Uninstall,
    [switch]$NoFont,
    [switch]$Scan,
    [switch]$CleanOld,
    [string]$GameDir = ''
)
$ErrorActionPreference = 'Stop'
$packRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

$PatchFiles = @(
    'pakchunk99-ZH_Locres_P.pak',
    'pakchunk99-ZH_UAsset-Windows.pak',
    'pakchunk99-ZH_UAsset-Windows.utoc',
    'pakchunk99-ZH_UAsset-Windows.ucas',
    'pakchunk100-ZH_Fonts_P.pak'
)
$FontFile = 'pakchunk100-ZH_Fonts_P.pak'
$ExpectedBuild = '24024260'
$ExpectedVersion = 'Hotfix Patch 1.1.2'

function Find-GameDir {
    $cands = New-Object System.Collections.Generic.List[string]
    foreach ($d in (Get-PSDrive -PSProvider FileSystem).Root) {
        $cands.Add((Join-Path $d 'SteamLibrary\steamapps\common\IntoTheRadius2'))
        $cands.Add((Join-Path $d 'Steam\steamapps\common\IntoTheRadius2'))
        $cands.Add((Join-Path $d 'Program Files (x86)\Steam\steamapps\common\IntoTheRadius2'))
        $cands.Add((Join-Path $d 'Games\IntoTheRadius2'))
    }
    $cands.Add('C:\Program Files (x86)\Steam\steamapps\common\IntoTheRadius2')
    foreach ($c in $cands) {
        if (Test-Path (Join-Path $c 'IntoTheRadius2.exe')) { return $c }
    }
    return ''
}

function Show-VersionCheck([string]$root) {
    try {
        $steamapps = Split-Path -Parent (Split-Path -Parent $root)
        $acf = Join-Path $steamapps 'appmanifest_2307350.acf'
        if (Test-Path $acf) {
            $line = (Get-Content $acf | Where-Object { $_ -match '"buildid"' } | Select-Object -First 1)
            if ($line) {
                $build = ($line -replace '[^0-9]', '')
                Write-Host ("[i] 游戏 buildid = " + $build + "（本补丁基准 " + $ExpectedBuild + " / " + $ExpectedVersion + "）")
                if ($build -ne $ExpectedBuild) {
                    Write-Host '[!] buildid 与补丁基准不一致：游戏更新后 locres/uasset 偏移可能变化，补丁可能部分或全部失效。' -ForegroundColor Yellow
                }
            }
        }
    } catch { }
}

function Show-Banner([string]$title) {
    Write-Host ''
    Write-Host ('=' * 62)
    Write-Host ('  Into the Radius 2 简体中文补丁 · ' + $title)
    Write-Host ('=' * 62)
}

# ---- 既有汉化/补丁残留扫描与清理 ----
# 分级处理：本补丁文件、非 en 语言目录、松散 locres、旧的 DefaultCulture 配置为
# 「确定项」，可直接清理；其它 *_P.pak、~mods、LogicMods 内容可能是别的 mod，
# 一律列出清单并逐个询问，直接回车 = 保留（绝不误删）。
function Get-Residue([string]$root) {
    $paks = Join-Path $root 'IntoTheRadius2\Content\Paks'
    $loc = Join-Path $root 'IntoTheRadius2\Content\Localization\Game'
    $own = @(); $patch = @(); $mods = @(); $logic = @(); $lang = @(); $loose = @(); $cfg = @()
    foreach ($f in $PatchFiles) {
        if (Test-Path -LiteralPath (Join-Path $paks $f)) { $own += $f }
    }
    if (Test-Path -LiteralPath $paks) {
        foreach ($f in @(Get-ChildItem -LiteralPath $paks -File -Filter '*.pak' -ErrorAction SilentlyContinue)) {
            if ($PatchFiles -notcontains $f.Name -and $f.Name -ne 'pakchunk0-Windows.pak') { $patch += $f.FullName }
        }
        foreach ($sub in @('~mods', 'LogicMods')) {
            $d = Join-Path $paks $sub
            if (Test-Path -LiteralPath $d) {
                $items = @(Get-ChildItem -LiteralPath $d -File -Recurse -ErrorAction SilentlyContinue | ForEach-Object { $_.FullName })
                if ($sub -eq '~mods') { $mods = $items } else { $logic = $items }
            }
        }
    }
    foreach ($n in @('zh-Hans', 'zh-Hant', 'zh', 'chs', 'cht', 'zh_CN', 'zh_TW')) {
        $p = Join-Path $loc $n
        if (Test-Path -LiteralPath $p) { $lang += $p }
    }
    if (Test-Path -LiteralPath $loc) {
        foreach ($f in @(Get-ChildItem -LiteralPath $loc -Recurse -File -ErrorAction SilentlyContinue)) {
            if (($f.Extension -eq '.locres' -or $f.Extension -eq '.locmeta') -and $f.FullName -notmatch '\\en\\') {
                $inLang = $false
                foreach ($d in $lang) {
                    if ($f.FullName.StartsWith($d, [System.StringComparison]::OrdinalIgnoreCase)) { $inLang = $true }
                }
                if (-not $inLang) { $loose += $f.FullName }
            }
        }
    }
    foreach ($rel in @('IntoTheRadius2\Saved\Config\Windows\DeviceProfiles.ini',
                       'IntoTheRadius2\Saved\Config\Windows\Game.ini')) {
        $c = Join-Path $root $rel
        if (Test-Path -LiteralPath $c) {
            $hits = @(Get-Content -LiteralPath $c -ErrorAction SilentlyContinue |
                      Where-Object { $_ -match '^\s*DefaultCulture\s*=' })
            if ($hits.Count -gt 0) { $cfg += $c }
        }
    }
    return [pscustomobject]@{
        Own = $own; Patch = $patch; Mods = $mods; Logic = $logic
        Lang = $lang; Loose = $loose; Config = $cfg
    }
}

function Show-Residue($r) {
    if ($r.Own.Count)   { Write-Host ('  · 本补丁的旧安装文件: ' + $r.Own.Count + ' 个') }
    if ($r.Lang.Count)  { Write-Host ('  · 旧版松散汉化语言目录: ' + $r.Lang.Count + ' 个')
                          foreach ($p in $r.Lang) { Write-Host ('      ' + $p) } }
    if ($r.Loose.Count) { Write-Host ('  · 非 en 的松散本地化文件: ' + $r.Loose.Count + ' 个')
                          foreach ($p in $r.Loose) { Write-Host ('      ' + $p) } }
    if ($r.Patch.Count) { Write-Host ('  · 其它补丁 pak（可能是别的汉化/补丁）: ' + $r.Patch.Count + ' 个')
                          foreach ($p in $r.Patch) { Write-Host ('      ' + $p) } }
    if ($r.Mods.Count)  { Write-Host ('  · ~mods 目录内容: ' + $r.Mods.Count + ' 个')
                          foreach ($p in $r.Mods) { Write-Host ('      ' + $p) } }
    if ($r.Logic.Count) { Write-Host ('  · LogicMods 目录内容: ' + $r.Logic.Count + ' 个')
                          foreach ($p in $r.Logic) { Write-Host ('      ' + $p) } }
    if ($r.Config.Count){ Write-Host ('  · 配置中的 DefaultCulture 设置: ' + $r.Config.Count + ' 个')
                          foreach ($p in $r.Config) { Write-Host ('      ' + $p) } }
}

function Invoke-CleanResidue([string]$root, $r) {
    $paks = Join-Path $root 'IntoTheRadius2\Content\Paks'
    $n = 0
    foreach ($f in $r.Own) {
        $p = Join-Path $paks $f
        if (Test-Path -LiteralPath $p) {
            Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue
            Write-Host "[OK] 已删除 $f"; $n++
        }
    }
    foreach ($d in $r.Lang) {
        if (Test-Path -LiteralPath $d) {
            Remove-Item -LiteralPath $d -Recurse -Force -ErrorAction SilentlyContinue
            Write-Host ('[OK] 已删除语言目录 ' + $d); $n++
        }
    }
    foreach ($f in $r.Loose) {
        if (Test-Path -LiteralPath $f) {
            Remove-Item -LiteralPath $f -Force -ErrorAction SilentlyContinue
            Write-Host ('[OK] 已删除 ' + $f); $n++
        }
    }
    foreach ($c in $r.Config) {
        $before = @(Get-Content -LiteralPath $c)
        $after = @($before | Where-Object { $_ -notmatch '^\s*DefaultCulture\s*=' })
        if ($after.Count -ne $before.Count) {
            # 无 BOM UTF-8 写回：PowerShell 5.1 的 -Encoding UTF8 会写入 BOM，
            # 可能使配置首节失效
            [System.IO.File]::WriteAllLines($c, $after, (New-Object System.Text.UTF8Encoding($false)))
            Write-Host ('[OK] 已清理 ' + $c + ' 中的 DefaultCulture 设置'); $n++
        }
    }
    foreach ($f in @($r.Patch + $r.Mods + $r.Logic)) {
        Write-Host ''
        Write-Host ('[?] 疑似其它来源的文件: ' + $f) -ForegroundColor Yellow
        $ans = ''
        try { $ans = Read-Host '    删除请按 D 后回车，直接回车 = 保留' } catch { $ans = '' }
        if ($ans -eq 'D' -or $ans -eq 'd') {
            Remove-Item -LiteralPath $f -Recurse -Force -ErrorAction SilentlyContinue
            Write-Host '[OK] 已删除'
            $n++
        } else {
            Write-Host '[skip] 已保留'
        }
    }
    return $n
}

Show-Banner $(if ($Scan) { '汉化残留扫描' }
              elseif ($CleanOld) { '汉化残留清理' }
              elseif ($Uninstall) { '卸载向导' }
              else { '安装向导' })
if (-not $Scan -and -not $CleanOld -and -not $Uninstall) {
    Write-Host '[教程] 安装流程（约 1 分钟，无需启动参数）：'
    Write-Host '  1. 前置检查：确认游戏版本、退出游戏、具备写入权限'
    Write-Host '  2. 安装补丁：将补丁文件复制到游戏 Paks 目录'
    Write-Host '  3. 启动验证：进入游戏确认界面为简体中文'
    Write-Host '  详细说明与常见问题见随包《汉化说明.md》。'
    Write-Host ''
    Write-Host '-- 步骤 1/3 前置检查 --'
}
if (-not $GameDir) { $GameDir = Find-GameDir }
if (-not $GameDir -or
    -not (Test-Path -LiteralPath $GameDir -ErrorAction SilentlyContinue) -or
    -not (Test-Path -LiteralPath (Join-Path $GameDir 'IntoTheRadius2.exe') -ErrorAction SilentlyContinue)) {
    Write-Host '[X] 找不到 Into the Radius 2 安装目录，请手动指定：' -ForegroundColor Red
    Write-Host "    powershell -NoProfile -ExecutionPolicy Bypass -File install.ps1 -GameDir 'D:\SteamLibrary\steamapps\common\IntoTheRadius2'"
    Write-Host '    若仍无法解决，请参阅随包《汉化说明.md》第一节。'
    exit 1
}

$paks = Join-Path $GameDir 'IntoTheRadius2\Content\Paks'
Write-Host "[i] 游戏目录: $GameDir"
Write-Host "[i] Paks 目录: $paks"
Show-VersionCheck $GameDir
# 游戏运行中会占用 pak 文件，必须先行退出，否则覆盖会失败
$running = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like 'IntoTheRadius2*' })
if ($running.Count -gt 0) {
    Write-Host '[X] 检测到游戏正在运行（IntoTheRadius2.exe），请先完全退出游戏后再执行本脚本。' -ForegroundColor Red
    foreach ($p in $running) { Write-Host ("    运行中的进程: " + $p.ProcessName + " (PID " + $p.Id + ")") }
    exit 1
}

$residue = Get-Residue $GameDir
$residueTotal = $residue.Own.Count + $residue.Patch.Count + $residue.Mods.Count +
                $residue.Logic.Count + $residue.Lang.Count + $residue.Loose.Count + $residue.Config.Count

if ($Scan) {
    Write-Host ''
    Write-Host '-- 扫描既有汉化 / 补丁残留 --'
    if ($residueTotal -eq 0) {
        Write-Host '[OK] 未发现既有汉化或补丁残留。'
    } else {
        Write-Host "[i] 共发现 $residueTotal 项："
        Show-Residue $residue
        Write-Host ''
        Write-Host '[教程] 清理方式：运行安装器并选择 [4]，或执行 install.ps1 -CleanOld。'
    }
    exit 0
}

if ($CleanOld) {
    Write-Host ''
    Write-Host '-- 清理既有汉化 / 补丁残留 --'
    if ($residueTotal -eq 0) {
        Write-Host '[OK] 未发现既有汉化或补丁残留，无需清理。'
        exit 0
    }
    Write-Host "[i] 共发现 $residueTotal 项："
    Show-Residue $residue
    Write-Host ''
    $cleaned = Invoke-CleanResidue $GameDir $residue
    Write-Host ''
    Write-Host "[OK] 清理完成，共处理 $cleaned 项。"
    Write-Host '[教程] 重新汉化：运行安装器并选择 [1] 安装简体中文补丁。'
    Write-Host '  · 若 Steam 启动选项里留有 -CULTURE=... 参数，请一并删除。'
    exit 0
}

if ($Uninstall) {
    $n = 0
    foreach ($f in $PatchFiles) {
        $p = Join-Path $paks $f
        if (Test-Path $p) { Remove-Item $p -Force; Write-Host "[OK] 已删除 $f"; $n++ }
    }
    $oldLoc = Join-Path $GameDir 'IntoTheRadius2\Content\Localization\Game\zh-Hans'
    if (Test-Path $oldLoc) {
        Remove-Item $oldLoc -Recurse -Force
        Write-Host '[OK] 已清理旧版(v1)残留: Content\Localization\Game\zh-Hans'
    }
    foreach ($rel in @('IntoTheRadius2\Saved\Config\Windows\DeviceProfiles.ini', 'IntoTheRadius2\Saved\Config\Windows\Game.ini')) {
        $cf = Join-Path $GameDir $rel
        if (Test-Path $cf) {
            $before = @(Get-Content $cf)
            $after = @($before | Where-Object { $_ -notmatch '^\s*DefaultCulture\s*=' })
            if ($after.Count -ne $before.Count) {
                [System.IO.File]::WriteAllLines($cf, $after, (New-Object System.Text.UTF8Encoding($false)))
                Write-Host "[OK] 已清理 $rel 中的旧版 DefaultCulture 设置"
            }
        }
    }
    Write-Host ''
    Write-Host '[OK] 卸载完成（共移除 $n 个补丁文件），游戏已还原为英文原版。'
    Write-Host '[教程] 后续：'
    Write-Host '  · 重新安装：再次运行「安装汉化.cmd」。'
    Write-Host '  · 若启动项中留有 -CULTURE=zh-Hans 参数，请一并删除。'
    exit 0
}

if (-not (Test-Path $paks)) {
    Write-Host "[X] 目录不存在: $paks" -ForegroundColor Red
    Write-Host '    请确认 -GameDir 指向的是游戏根目录（含 IntoTheRadius2.exe）。'
    exit 1
}

# 写入权限检查：Steam 库若位于 Program Files 等受保护位置，需要以管理员身份运行
$probe = Join-Path $paks ('.itr2zh_write_test_' + [guid]::NewGuid().ToString('N'))
$writable = $true
try {
    Set-Content -Path $probe -Value 'test' -ErrorAction Stop
    Remove-Item $probe -Force -ErrorAction SilentlyContinue
} catch {
    $writable = $false
}
if (-not $writable) {
    Write-Host '[X] 没有写入权限，无法安装到该目录。' -ForegroundColor Red
    Write-Host '    请右键点击 安装汉化.cmd，选择“以管理员身份运行”。'
    exit 1
}

if ($residueTotal -gt 0) {
    Write-Host "[!] 发现 $residueTotal 项既有汉化 / 补丁残留（可能与本补丁冲突）：" -ForegroundColor Yellow
    Show-Residue $residue
    $certain = $residue.Own.Count + $residue.Lang.Count + $residue.Loose.Count + $residue.Config.Count
    if ($certain -gt 0) {
        Write-Host ''
        $ans = ''
        try { $ans = Read-Host '[?] 先清理本补丁旧安装文件与旧版松散汉化残留？(Y/N，回车 = 否)' } catch { $ans = '' }
        if ($ans -eq 'Y' -or $ans -eq 'y') {
            $only = [pscustomobject]@{
                Own = $residue.Own; Lang = $residue.Lang; Loose = $residue.Loose
                Config = $residue.Config; Patch = @(); Mods = @(); Logic = @()
            }
            $cleaned = Invoke-CleanResidue $GameDir $only
            Write-Host "[OK] 已清理 $cleaned 项旧安装残留。"
        } else {
            Write-Host '[skip] 保留现有文件，继续安装（同名文件将被覆盖）。'
        }
    }
    if ($residue.Patch.Count -gt 0 -or $residue.Mods.Count -gt 0 -or $residue.Logic.Count -gt 0) {
        Write-Host '[i] 其它来源的文件未自动处理；如需彻底清理，请运行安装器选择 [4] 逐个确认。'
    }
}
Write-Host '[OK] 前置检查通过'

Write-Host ''
Write-Host '-- 步骤 2/3 安装补丁 --'
$copied = 0
foreach ($f in $PatchFiles) {
    if ($f -eq $FontFile -and $NoFont) { Write-Host "[skip] $f（已指定 -NoFont）"; continue }
    $src = Join-Path $packRoot $f
    if (-not (Test-Path $src)) { Write-Host "[!] 缺少文件: $f" -ForegroundColor Yellow; continue }
    Copy-Item $src (Join-Path $paks $f) -Force
    Write-Host "[OK] 已安装 $f"
    $copied++
}
Write-Host ''
Write-Host '-- 步骤 3/3 安装完成 --'
Write-Host "[OK] 共安装 $copied 个补丁文件。"
Write-Host '[教程] 后续使用：'
Write-Host '  · 直接启动游戏，界面、任务、物品说明与字幕为简体中文（无需启动参数或语言设置）。'
Write-Host '  · 文字显示为方框或空白：请改用「不含字体」方式安装，并到发布页反馈。'
Write-Host '  · 游戏更新后中文失效：请先卸载，待补丁更新后重新安装。'
Write-Host '  · 卸载或重新安装：重新运行安装程序并选择对应选项（压缩包版可双击对应 .cmd）。'
Write-Host '[i] 授权信息见随包 LICENSE、NOTICE 与 licenses\OFL-NotoSansSC.txt。'
