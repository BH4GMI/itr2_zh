﻿param(
    [switch]$Uninstall,
    [switch]$NoFont,
    [string]$GameDir = ''
)
$ErrorActionPreference = 'Stop'
$packRoot = Split-Path -Parent $MyInvocation.MyCommand.Path

$PatchFiles = @(
    'pakchunk99-ZH_Locres_P.pak',
    'pakchunk99-ZH_UAsset-Windows.pak',
    'pakchunk99-ZH_UAsset-Windows.utoc',
    'pakchunk99-ZH_UAsset-Windows.ucas',
    'pakchunk100-ZH_Fonts_P.pak'
)
$FontFile = 'pakchunk100-ZH_Fonts_P.pak'
$ExpectedBuild = '24024260'
$ExpectedVersion = 'Hotfix Patch 1.1.2'

function Find-GameDir {
    $cands = New-Object System.Collections.Generic.List[string]
    foreach ($d in (Get-PSDrive -PSProvider FileSystem).Root) {
        $cands.Add((Join-Path $d 'SteamLibrary\steamapps\common\IntoTheRadius2'))
        $cands.Add((Join-Path $d 'Steam\steamapps\common\IntoTheRadius2'))
        $cands.Add((Join-Path $d 'Program Files (x86)\Steam\steamapps\common\IntoTheRadius2'))
        $cands.Add((Join-Path $d 'Games\IntoTheRadius2'))
    }
    $cands.Add('C:\Program Files (x86)\Steam\steamapps\common\IntoTheRadius2')
    foreach ($c in $cands) {
        if (Test-Path (Join-Path $c 'IntoTheRadius2.exe')) { return $c }
    }
    return ''
}

function Show-VersionCheck([string]$root) {
    try {
        $steamapps = Split-Path -Parent (Split-Path -Parent $root)
        $acf = Join-Path $steamapps 'appmanifest_2307350.acf'
        if (Test-Path $acf) {
            $line = (Get-Content $acf | Where-Object { $_ -match '"buildid"' } | Select-Object -First 1)
            if ($line) {
                $build = ($line -replace '[^0-9]', '')
                Write-Host ("[i] 游戏 buildid = " + $build + "（本补丁基准 " + $ExpectedBuild + " / " + $ExpectedVersion + "）")
                if ($build -ne $ExpectedBuild) {
                    Write-Host '[!] buildid 与补丁基准不一致：游戏更新后 locres/uasset 偏移可能变化，补丁可能部分或全部失效。' -ForegroundColor Yellow
                }
            }
        }
    } catch { }
}

if (-not $GameDir) { $GameDir = Find-GameDir }
if (-not $GameDir -or -not (Test-Path (Join-Path $GameDir 'IntoTheRadius2.exe'))) {
    Write-Host '[X] 找不到 Into the Radius 2 安装目录，请手动指定：' -ForegroundColor Red
    Write-Host "    powershell -NoProfile -ExecutionPolicy Bypass -File install.ps1 -GameDir 'D:\SteamLibrary\steamapps\common\IntoTheRadius2'"
    exit 1
}

$paks = Join-Path $GameDir 'IntoTheRadius2\Content\Paks'
Write-Host "[i] 游戏目录: $GameDir"
Write-Host "[i] Paks 目录: $paks"
Show-VersionCheck $GameDir

# 游戏运行中会占用 pak 文件，必须先行退出，否则覆盖会失败
$running = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like 'IntoTheRadius2*' })
if ($running.Count -gt 0) {
    Write-Host '[X] 检测到游戏正在运行（IntoTheRadius2.exe），请先完全退出游戏后再执行本脚本。' -ForegroundColor Red
    foreach ($p in $running) { Write-Host ("    运行中的进程: " + $p.ProcessName + " (PID " + $p.Id + ")") }
    exit 1
}

if ($Uninstall) {
    $n = 0
    foreach ($f in $PatchFiles) {
        $p = Join-Path $paks $f
        if (Test-Path $p) { Remove-Item $p -Force; Write-Host "[OK] 已删除 $f"; $n++ }
    }
    $oldLoc = Join-Path $GameDir 'IntoTheRadius2\Content\Localization\Game\zh-Hans'
    if (Test-Path $oldLoc) {
        Remove-Item $oldLoc -Recurse -Force
        Write-Host '[OK] 已清理旧版(v1)残留: Content\Localization\Game\zh-Hans'
    }
    foreach ($rel in @('IntoTheRadius2\Saved\Config\Windows\DeviceProfiles.ini', 'IntoTheRadius2\Saved\Config\Windows\Game.ini')) {
        $cf = Join-Path $GameDir $rel
        if (Test-Path $cf) {
            $before = @(Get-Content $cf)
            $after = @($before | Where-Object { $_ -notmatch '^\s*DefaultCulture\s*=' })
            if ($after.Count -ne $before.Count) {
                Set-Content -Path $cf -Value $after -Encoding UTF8
                Write-Host "[OK] 已清理 $rel 中的旧版 DefaultCulture 设置"
            }
        }
    }
    Write-Host "[OK] 卸载完成（共移除 $n 个补丁文件）。若启动项里还留着 -CULTURE=zh-Hans，请一并删掉。"
    exit 0
}

if (-not (Test-Path $paks)) {
    Write-Host "[X] 目录不存在: $paks" -ForegroundColor Red
    Write-Host '    请确认 -GameDir 指向的是游戏根目录（含 IntoTheRadius2.exe）。'
    exit 1
}

# 写入权限检查：Steam 库若位于 Program Files 等受保护位置，需要以管理员身份运行
$probe = Join-Path $paks ('.itr2zh_write_test_' + [guid]::NewGuid().ToString('N'))
$writable = $true
try {
    Set-Content -Path $probe -Value 'test' -ErrorAction Stop
    Remove-Item $probe -Force -ErrorAction SilentlyContinue
} catch {
    $writable = $false
}
if (-not $writable) {
    Write-Host '[X] 没有写入权限，无法安装到该目录。' -ForegroundColor Red
    Write-Host '    请右键点击 安装汉化.cmd，选择“以管理员身份运行”。'
    exit 1
}

$others = @(Get-ChildItem $paks -Filter '*_P.pak' -ErrorAction SilentlyContinue | Where-Object { $PatchFiles -notcontains $_.Name })
if ($others.Count -gt 0) {
    Write-Host '[!] 检测到其它补丁 pak，可能与本补丁冲突；如遇异常请先移除：' -ForegroundColor Yellow
    foreach ($o in $others) { Write-Host ("    " + $o.Name) }
}

$copied = 0
foreach ($f in $PatchFiles) {
    if ($f -eq $FontFile -and $NoFont) { Write-Host "[skip] $f（已指定 -NoFont）"; continue }
    $src = Join-Path $packRoot $f
    if (-not (Test-Path $src)) { Write-Host "[!] 缺少文件: $f" -ForegroundColor Yellow; continue }
    Copy-Item $src (Join-Path $paks $f) -Force
    Write-Host "[OK] 已安装 $f"
    $copied++
}
Write-Host "[OK] 安装完成（共 $copied 个文件）。直接启动游戏即可，无需启动参数，亦无需在设置中切换语言。"
Write-Host '[i] 授权信息见随包 LICENSE、NOTICE 与 licenses\OFL-NotoSansSC.txt。'
